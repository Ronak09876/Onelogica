package com.HRmanagementsystem.exception;



public class DepartmentException extends Exception {
	
	public DepartmentException(String message) {
		super(message);
	}

}
